"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Md1Service = void 0;
const common_1 = require("@nestjs/common");
let Md1Service = class Md1Service {
    constructor() {
        this.md1Authors = [
            {
                id: 1,
                name: "Issac Asimov"
            },
            {
                id: 2,
                name: 'Dan Brown'
            },
            {
                id: 3,
                name: 'Alexandre Dumas'
            }
        ];
        this.md1Books = [
            {
                id: 1,
                title: 'Robot Dreams',
                author: 1
            },
            {
                id: 2,
                title: 'The Starts, Like Dust',
                author: 1
            },
            {
                id: 3,
                title: 'Digital Fortress',
                author: 2
            },
            {
                id: 4,
                title: 'The Three Mosketeers',
                author: 3
            }
        ];
        this.md1Reviews = [
            {
                id: 1,
                text: 'Awesome Book!',
                book: 1
            },
            {
                id: 2,
                text: 'Great Book!',
                book: 1
            },
            {
                id: 3,
                text: 'Amazing Book!',
                book: 2
            },
            {
                id: 4,
                text: 'Fantastic Book!',
                book: 3
            }
        ];
    }
    findAllAuthors(id, name) {
        if (id != null) {
            const autor = this.md1Authors.find(i => i.id === id);
            if (!autor)
                throw new common_1.NotFoundException(`Autor con ID [${id}] no existe`);
            return [autor];
        }
        if (name != null) {
            const autor = this.md1Authors.find(i => i.name === name);
            if (!autor)
                throw new common_1.NotFoundException(`Autor con NOMBRE [${name}] no existe`);
            return [autor];
        }
        return this.md1Authors;
    }
    findAllBooks() {
        return this.md1Books;
    }
    findAllReviews() {
        return this.md1Reviews;
    }
};
Md1Service = __decorate([
    (0, common_1.Injectable)()
], Md1Service);
exports.Md1Service = Md1Service;
//# sourceMappingURL=md1.service.js.map