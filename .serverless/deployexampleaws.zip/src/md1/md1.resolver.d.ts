import { authors, books, reviews } from './entity/md1.entity';
import { Md1Service } from './md1.service';
export declare class Md1Resolver {
    private readonly md1Service;
    constructor(md1Service: Md1Service);
    hola(): string;
    authors(id: number, name: String): authors[];
    Books(): books[];
    reviews(): reviews[];
}
