"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Md1Resolver = void 0;
const graphql_1 = require("@nestjs/graphql");
const md1_entity_1 = require("./entity/md1.entity");
const md1_service_1 = require("./md1.service");
let Md1Resolver = class Md1Resolver {
    constructor(md1Service) {
        this.md1Service = md1Service;
    }
    hola() {
        return 'kayzero ingeniero';
    }
    authors(id, name) {
        return this.md1Service.findAllAuthors(id, name);
    }
    Books() {
        return this.md1Service.findAllBooks();
    }
    reviews() {
        return this.md1Service.findAllReviews();
    }
};
__decorate([
    (0, graphql_1.Query)(() => String),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", String)
], Md1Resolver.prototype, "hola", null);
__decorate([
    (0, graphql_1.Query)(() => [md1_entity_1.authors]),
    __param(0, (0, graphql_1.Args)('id', { nullable: true, type: () => graphql_1.Int })),
    __param(1, (0, graphql_1.Args)('name', { nullable: true, type: () => String })),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number, String]),
    __metadata("design:returntype", Array)
], Md1Resolver.prototype, "authors", null);
__decorate([
    (0, graphql_1.Query)(() => [md1_entity_1.books]),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Array)
], Md1Resolver.prototype, "Books", null);
__decorate([
    (0, graphql_1.Query)(() => [md1_entity_1.reviews]),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Array)
], Md1Resolver.prototype, "reviews", null);
Md1Resolver = __decorate([
    (0, graphql_1.Resolver)(),
    __metadata("design:paramtypes", [md1_service_1.Md1Service])
], Md1Resolver);
exports.Md1Resolver = Md1Resolver;
//# sourceMappingURL=md1.resolver.js.map