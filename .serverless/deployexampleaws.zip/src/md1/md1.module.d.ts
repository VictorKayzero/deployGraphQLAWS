export declare class Md1Module {
}
