import { authors, books, reviews } from './entity/md1.entity';
export declare class Md1Service {
    private md1Authors;
    findAllAuthors(id: number, name: String): authors[];
    private md1Books;
    findAllBooks(): books[];
    private md1Reviews;
    findAllReviews(): reviews[];
}
