export declare class authors {
    id: number;
    name: String;
}
export declare class books {
    id: number;
    title: String;
    author: number;
}
export declare class reviews {
    id: number;
    text: String;
    book: number;
}
